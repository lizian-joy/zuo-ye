//
//  main.cpp
//  交通工具换乘方案
//
//  Created by 小猪仔 on 2019/12/24.
//  Copyright © 2019 test_pro. All rights reserved.
//
//基于十堰市的交通工具换乘方案
//
/*
14
建设大道兴丽城
建设大道路口
东风四中
东风刃量具厂
市艺校
方山
龙泉寺
市十八中
交警四大队
东风铸造一厂
花果
轧钢厂
西城开发区
西沟口
西城植物园
小堰沟
高湾
黄土村
关岭瀑布
黄土村村委会
顾家沟
桑皮垭
连心桥
西沟乡卫生院
西沟乡政府
杨家沟口
沙洲站
南沟口
过风楼
过风村
过风村村委会
长坪塘村一组
长坪塘村二组
长坪塘村委会
白石一组
白石二组
白石七组
岳竹村
 34
 市艺校
 东风刃量具厂
 东风四中
 建设大道路口
 建设大道兴丽城
 东风越野车公司
 东风征梦公司
 精益铜板公司
 魏家沟
 新宇路路口
 风行路路口
 交警四大队
 东风铸造一厂
 三公司二处
 花果街
 花果
 花果火车站
 千字沟
 轧钢厂
 西城开发区
 西沟口
 堰西(驾考中心)
 39
 建设大道兴丽城
 东风修造厂
 修造厂二号门
 修造厂新村
 东风天业公司
 蝶翠豪庭
 车身厂俱乐部
 车身厂二区
 万佳驾校(原东风配套处)
 中岳路中路
 中岳路(东)
 三堰农贸市场
 五四厂小区
 上海路金座
 大美盛城
 上海路中路
 上海路(东)
 惠泽公园1号
 公交信息中心(重庆路)
 重庆路小学
 重庆路(中)
 神鹰改装厂
 东城之光.现代城
 三环专汽
 第四人民医院
 马家河
 24
 公交四公司
 人民广场
 东风总医院
 青年广场
 东风零部件集团总部
 东风供应处
 东风水箱厂
 恒融·枫尚城（原金星市场）
 东风技校
 湖北汽车工业学院
 红卫
 东风四中
 东风刃量具厂
 市艺校
 采石场
 路路通公司
 方山
 龙泉寺
 市十八中
 交警四大队
 东风铸造一厂
 三公司二处
 花果
 东风轴瓦厂
 东风制动系统公司
 5
 火车站南广场
 公交二公司
 青少年宫
 寿康生活广场
 擂鼓台
 太和医院
 三堰邮局
 三堰客运站
 十堰日报社
 中国银行
 十堰军分区(上行停靠工贸家电)
 五堰王子鞋城
 文化广场(1号站台)
 工人文化宫
 人民广场
 人民公园
 东风总医院
 张湾区政府
 青年广场
 东风零部件集团总部
 东风供应处
 东风水箱厂
 恒融·枫尚城（原金星市场）
 东风技校
 湖北汽车工业学院
 */
//#include <iostream>
//
//int main(int argc, const char * argv[]) {
//    printf("输入起点和目的地，将为你提供最优出行方案/n");
//
//    // insert code here...
//    std::cout << "Hello, World!\n";
//    return 0;
//}


//
#include<stdio.h>
#include<stdlib.h>
//#define Maxsize 100
#include <iostream>
//
using namespace std;
//
//typedef struct edge
//{
//    int ivex;
//    struct edge *next;
//}ENode;
//
//typedef struct  VNode
//{
//    char data;
//    ENode *first;
//}VNode;
//
//typedef struct
//{
//    int vnum,anum;
//    VNode vex[100];
//}Graph;
//
//int Find(Graph G,char x)
//{
//    int j=0;
//    for(int k=0;k<G.vnum;k++)
//    {
//        if(G.vex[k].data==x)
//        {
//            j=k;
//            break;
//        }
//    }
//    return j;
//}
//
//void Creat(Graph &G)
//{
//    ENode *p1;
//    int i,j,k;
//    char v1,v2;
//    cin>>G.vnum;
//    for(i=0;i<G.vnum;++i)
//    {
//        cin>>G.vex[i].data;
//        G.vex[i].first=NULL;
//    }
//    cin>>G.anum;
//    for(k=0;k<G.anum;++k)
//    {
//        cin>>v1>>v2;
//        i=Find(G,v1);
//        j=Find(G,v2);
//        p1=(ENode *)malloc(sizeof(ENode));
//        p1->ivex=j;
//        p1->next=G.vex[i].first;
//        G.vex[i].first=p1;
//    }
//}
//static void DFS(Graph G,int i,int *visited)
//{
//    ENode *p;
//    visited[i]=1;
//    printf("%c ",G.vex[i].data);
//    p=G.vex[i].first;
//    while(p!=NULL)
//    {
//        if(!visited[p->ivex])
//            DFS(G,p->ivex,visited);
//        p=p->next;
//    }
//}
//void DFSTraverse(Graph G)
//{
//    int i;
//    int visited[100];
//    for(i=0;i<G.vnum;i++)
//        visited[i]=0;
//    for(i=0;i<G.vnum;i++)
//    {
//        if(!visited[i])
//            DFS(G,i,visited);
//    }
//}
//void BFS(Graph G)
//{
//    int head=0,rear=0,i,j,k;
//    int quee[100];
//    int visited[100];
//    ENode *p;
//    for(i=0;i<G.vnum;i++)
//    {
//        visited[i]=0;
//    }
//    for(i=0;i<G.vnum;i++)
//    {
//        if(!visited[i])
//        {
//            visited[i]=1;
//            printf("%c ",G.vex[i].data);
//            quee[rear++]=i;
//        }
//        while(head!=rear)
//        {
//            j=quee[head++];
//            p=G.vex[j].first;
//            while(p!=NULL)
//            {
//                k=p->ivex;
//                if(!visited[k])
//                {
//                    visited[k]=1;
//                    printf("%c ",G.vex[k].data);
//                    quee[rear++]=k;
//                }
//                p=p->next;
//            }
//        }
//    }
//}
//
//int main()
//{
//    Graph G;
//    Creat(G);
//    DFSTraverse(G);
//    printf("\n");
//    BFS(G);
//    printf("\n");
//    return 0;
//}
//
//#include<iostream>
//using namespace std;
//
//typedef struct
//{
//    char nodes[100];//顶点表
//    int arcs[100][100];//边表 邻接矩阵 相邻接为1 否则为0
//    int num_nodes,num_arcs;//顶点数和边数
//}MGraph;//以邻接矩阵存储的图类型
//
//void CreatGraph(MGraph *&G)
//{
//    cout<<"please enter num is nodes and arcs:";
//    cin>>G->num_nodes>>G->num_arcs;//输入顶点数和边数
//    cout<<"please enter name is each vertex:";
//    for(int i=0;i<G->num_nodes;i++)
//    {
//        char ch;
//        cin>>ch;
//        G->nodes[i]=ch;//输入顶点信息
//    }
//    for(int p=0;p<G->num_nodes;p++)
//    {
//        for(int q=0;q<G->num_nodes;q++)
//            G->arcs[p][q]=0;//给每个顶点初始化 为0没有邻接
//    }
//    cout<<"please enter the relationship between each vertex and the value:";
//    for(int j=0;j<G->num_arcs;j++)
//    {
//        int a,b,c;
//        cin>>a>>b>>c;
//        while(a==b)
//        {
//            cout<<"error!please enter again:";
//            cin>>a>>b;
//        }
//        G->arcs[a][b]=c;//输入邻接的边，赋值他们的关系
//    }
//}
//
//void display(MGraph *&G)//输出邻接矩阵
//{
//    for(int i=0;i<G->num_nodes;i++)
//    {
//        for(int j=0;j<G->num_nodes;j++)
//        {
//            cout<<G->arcs[i][j]<<" ";//输出邻接矩阵表
//        }
//        cout<<endl;
//    }
//}
//
//int main()
//{
//    MGraph *g=new MGraph;
//    CreatGraph(g);
//    display(g);
//    return 1;
//}




//
//
//#include <iostream>
//using namespace std;
//#define MAX_VERTEX  20  //最多允许创建20个顶点的图
//typedef char DataType;
//typedef struct
//{
//    int vertexNum,edgeNum;
//    DataType vertexArr[MAX_VERTEX];       //顶点元素数组
//    int edgeArr[MAX_VERTEX][MAX_VERTEX]; //边矩阵二维数组
//
//}ArrayGraph;
//
//int visited[MAX_VERTEX] = {0};
//void ArrayGraph_init(ArrayGraph *pGraph);
//void ArrayGraph_create(ArrayGraph *pGraph);
//int locate_vertex(ArrayGraph *pGraph, DataType who);
//void ArrayGraph_show(ArrayGraph *pGraph);
//void DFTraverse(ArrayGraph *pGraph, int i);
//
//
////初始化为一个无圈图 ，也就是边矩阵中，主对角线元素都是0
//void ArrayGraph_init(ArrayGraph *pGraph)
//{
//    for (int i = 0; i < MAX_VERTEX; i++)
//    {
//        for(int j=0;j<MAX_VERTEX;j++)
//            pGraph->edgeArr[i][j] = 0;
//    }
//}
////输入一个图
//void ArrayGraph_create(ArrayGraph *pGraph)
//{
//    cout<<"请输入图的顶点个数（不超过20）：";
//    cin>>pGraph->vertexNum;
//    if (pGraph->vertexNum > MAX_VERTEX)
//    {
//        cout << "超过最大允许顶点数，请重新输入！"<<endl;
//        return ArrayGraph_create(pGraph);
//    }
//    for (int i = 0; i < pGraph->vertexNum; ++i)    //填充顶点数组，也就是输入顶点元素
//    {
//        cout<<"输入第"<<i + 1<<"个定点：";
//        cin>>pGraph->vertexArr[i];
//    }
//    cout << endl;
//    int choose;
//    cout << "请选择建立边关系的方式（建议大图选1.输入所有边之间的关系，小图选2.输入相连的顶点）:\t";
//    cin >> choose;
//    switch(choose){
//    case 1:
//        for (int j = 0; j <pGraph->vertexNum; ++j)   //填充边关系
//        {
//            for (int i = j + 1; i < pGraph->vertexNum; ++i)
//            {
//                cout << "若元素" << pGraph->vertexArr[j] << "和" << pGraph->vertexArr[i] << "有边，则输入1，否则输入0:" << '\t';
//                cin >> pGraph->edgeArr[j][i];
//                pGraph->edgeArr[i][j] = pGraph->edgeArr[j][i];     //对称
//            }
//        }break;
//    case 2:
//        cout<<"请输入边的数量:"<<" ";
//        cin >> pGraph->edgeNum;
//        while(pGraph->edgeNum > pGraph->vertexNum*(pGraph->vertexNum-1)/2) {
//            cout << "边数为不可能值，请重新输入:";
//            cin >> pGraph->edgeNum;
//        }
//        cout <<"\n请两两输入相连顶点:\n";
//        for (int i = 0; i <pGraph->edgeNum; ++i)
//        {
//            DataType s1, s2;//边的两端的顶点
//            cin >> s1 >> s2;
//            int index_1 = locate_vertex(pGraph, s1);//找到这两个顶点所在的下标
//            int index_2 = locate_vertex(pGraph, s2);
//            pGraph->edgeArr[index_1][index_2] = pGraph->edgeArr[index_2][index_1] = 1;//矩阵是对称的
//        }break;
//    default:cout<<choose<<"是无效运算符!";
//    }
//    cout << endl;
//}
//int locate_vertex(ArrayGraph *pGraph, DataType who)//寻找某个顶点的位置
//{
//    for (int i = 0; i < pGraph->vertexNum; ++i)
//        if (pGraph->vertexArr[i] == who)
//            return i;    //找到
//    return -1;//没找到
//}
//void ArrayGraph_show(ArrayGraph *pGraph)
//{
//    cout<<"\n顶点元素如下:\n";
//    for (int i = 0; i < pGraph->vertexNum; ++i)
//    {
//        cout<< pGraph->vertexArr[i]<<" ";
//    }
//    cout<<"\n";
//    cout<<"边矩阵如下:\n\n";
//    cout << "   ";
//    for (int i = 0; i<pGraph->vertexNum; ++i)
//        cout<<pGraph->vertexArr[i]<<"  ";
//    cout<<"\n";
//    for (int j = 0; j <pGraph->vertexNum; ++j)
//    {
//        cout<<pGraph->vertexArr[j]<<"  ";
//        for (int i = 0; i < pGraph->vertexNum; ++i)
//        {
//            cout<<pGraph->edgeArr[i][j]<<"  ";
//        }
//        cout<<"\n";
//    }
//    cout<<"\n";
//}
//void DFTraverse(ArrayGraph *pGraph, int i)
//{
//    cout<<" "<<pGraph->vertexArr[i];
//    visited[i] = 1;
//    for (int j = 0; j < pGraph->vertexNum; j++) {
//        if (pGraph->edgeArr[i][j] == 1 && visited[j] == 0)
//            DFTraverse(pGraph, j);
//    }
//}
//
//
//int main()
//{
//    ArrayGraph g;
//    ArrayGraph_init(&g);       //初始化图
//    ArrayGraph_create(&g);     //创建图
//    ArrayGraph_show(&g);       //打印图
//    cout<<"深度优先遍历序列是：";
//    DFTraverse(&g, 0);
//    cout << endl;
////    system("pause");
//    return 0;
//
//}
//
//
//

//创建路
//一级道路
//a-s
//d-t
//h-p
//j-q
//二级道路
//a-e
//e-l
//l-s
//d-e
//e-t
//j-q
//h-l
//l-p
//三级道路
//a-b
//b-c
//c-e
//e-l
//l-s
//d-e
//e-f
//f-g
//g-o
//o-t
//h-i
//i-k
//j-k
//k-l
//l-m
//m-n
//n-o
//o-p
//o-t
//l-s
//i-r
//r-q
//
//struct road{
//    char name[20];
//    char time[20];
//    char location[20];
//    int cdsl;
//    char cd[8];
//    char tz[20];
//    road*next;
//};
//





#include<stdio.h>
#include<stdlib.h>
#define Max 22
bool visited[Max];
//邻接矩阵
typedef struct {
    char vexs[Max];
    int arc[Max][Max];//邻接矩阵
    int vexnum, arcnum;//顶点数和边数
}MGraph;
//队列

typedef struct QNode {
    int data;
    struct QNode *next;
}QNode,*QueuePtr;

typedef struct {
    QueuePtr front, rear;
}LinkQueue;

int initQueue(LinkQueue *q) {
    q->front = q->rear = (QueuePtr)malloc(sizeof(QNode));
    if (!q->front) {
        return 0;
    }
    q->front->next = NULL;
    return 1;
}

int EnQueue(LinkQueue *q, int e) {
    QueuePtr s = (QueuePtr)malloc(sizeof(QNode));
    if (!s) {
        return 0;
    }
    s->data = e;
    s->next = NULL;
    q->rear->next = s;
    q->rear = s;
    return 1;

}
int DeQueue(LinkQueue *q, int *e) {
    QueuePtr p;
    if (q->front == q->rear) {
        return 0;
    }
    p = q->front->next;
    *e = p->data;
    q->front->next = p->next;
    if (q->rear == p) {
        q->rear = q->front;
    }
    free(p);
    return 1;
}
int QueueEmpty(LinkQueue q) {
    if (q.front == q.rear) {
        return 1;
    }
    return 0;
}



//返回顶点所在的位置
int Locatevex(MGraph G,char c) {
    for (int i = 0; i < G.vexnum; i++) {
        if (c == G.vexs[i]) {
            return i;
        }
    }
    return 0;
}
int test[20][20];
int x1,x2;
void CreateMGraph(MGraph *G) {
//    printf("请输入顶点数和边数:\n");
//    scanf("%d%d", &G->vexnum, &G->arcnum);
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    char city[19]={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s'};
    FILE*pig;
    pig=fopen("File", "r");
    fscanf(pig,"%d %d", &G->vexnum, &G->arcnum);
    printf("                       输入出发地和目的地的编号，空格隔开:                     \n");
//    printf("*************************************************************************\n");
    scanf("%c %c",&G->vexs[0],&G->vexs[1]);
    x1=G->vexs[0];
    x2=G->vexs[1];
    for (int i = 2,j=0; i < G->vexnum; i++,j++) {
//        getchar();
//        scanf("%c", &G->vexs[i]);
//        fscanf(pig,"%c", &G->vexs[i]);
        if(city[j]==G->vexs[0] ||city[j]==G->vexs[1])
            j++;
        G->vexs[i]=city[j];
//        printf("//%c %d\n",G->vexs[i],i);
    }
    for (int i = 0; i < G->vexnum; i++) {
        for (int j = 0; j < G->vexnum; j++) {
            G->arc[i][j] = 0;
        }
    }
    for (int m = 0; m < G->arcnum; m++) {
        char a, b;
        int i, j;
//        printf("输入边:\n");
//        getchar();
//        scanf("%c",&a);
        fscanf(pig, "%c",&a);

//        getchar();
//        scanf("%c", &b);
        fscanf(pig, "%c",&b);
//        printf("%c %c\n",a,b);
        i = Locatevex(*G, a);
        j = Locatevex(*G, b);
        G->arc[i][j]= 1;
        G->arc[j][i] = 1;
    }
    for(int i=0;i<20;++i)
    {
        for(int j=0;j<20;++j)
        {
            fscanf(pig,"%d",&test[i][j]);
        }
    }
}
   ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////   ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void DFS(MGraph G, int i) {
    visited[i] = true;
    printf("%c", G.vexs[i]);
    for (int j = 0; j < G.vexnum; j++) {
        if (G.arc[i][j] == 1 && !visited[j]) {
            DFS(G, j);
        }
    }
}

void DFSTraverse(MGraph G) {
    for (int i = 0; i < G.vexnum; i++) {
        visited[i] = false;
    }
    for (int j = 0; j < G.vexnum; j++) {
        if (!visited[j]) {
            DFS(G, j);
        }
    }
}

void BFSTraverse(MGraph G) {
    LinkQueue Q;
    for (int i = 0; i < G.vexnum; i++) {
        visited[i] = false;
    }
    initQueue(&Q);
    for (int i = 0; i < G.vexnum; i++) {
        if (!visited[i]) {
            visited[i] = true;
            printf("%c", G.vexs[i]);
            EnQueue(&Q, i);
        }
        while (!QueueEmpty(Q)) {
            DeQueue(&Q, &i);
            for (int j = 0; j < G.vexnum; j++) {
                if (G.arc[i][j] == 1 && !visited[j]) {
                    visited[j] = true;
                    printf("%c", G.vexs[j]);
                    EnQueue(&Q, j);
                }
            }
        }

    }
}


//邻接表
//边表节点
typedef struct EdgeNode {
    int adjvex;
struct EdgeNode *next;
}EdgeNode;

//顶点表节点
typedef struct VertexNode {
    char data;
    EdgeNode *first;
}VertexNode,AdjList[Max];

typedef struct {
    AdjList adjList;
    int vexnum, arcnum;//顶点数和边数
}graphAdjList,*GraphAdjList;
//构建邻接表
void CreateALGraph(MGraph G, GraphAdjList *GL)
{
    EdgeNode *e;

    *GL = (GraphAdjList)malloc(sizeof(graphAdjList));

    (*GL)->vexnum = G.vexnum;
    (*GL)->arcnum = G.arcnum;

    for (int i = 0; i<G.vexnum; i++)
    {
        (*GL)->adjList[i].data = G.vexs[i];
        (*GL)->adjList[i].first = NULL;
    }
    for (int k = 0; k<G.vexnum; k++)
    {
        for (int j = 0; j<G.vexnum; j++)
        {
            if (G.arc[k][j] == 1)
            {
                e = (EdgeNode *)malloc(sizeof(EdgeNode));
                e->adjvex = j;
                e->next = (*GL)->adjList[k].first;
                (*GL)->adjList[k].first = e;
            }
        }
    }
}
//邻接表的深度优先递归算法
void DFS(GraphAdjList GL, int i)
{
    EdgeNode *p;
    visited[i] = true;
    printf("%c ", GL->adjList[i].data);
    p = GL->adjList[i].first;
    while (p)
    {
        if (!visited[p->adjvex])
        {
            DFS(GL, p->adjvex);
        }
        p = p->next;

    }
}
int fdata[20];
//邻接表的深度遍历操作
void DFSTraverse(GraphAdjList GL)
{
    int i;
    for (i = 0; i<GL->vexnum; i++)
        visited[i] = false;//初始化
    for (i = 0; i<GL->vexnum; i++)
        if (!visited[i])
            DFS(GL, i);
}


//邻接表的广度遍历算法
void BFSTraverse(GraphAdjList GL)
{
    int fdatanum=0;
    EdgeNode *p;
    LinkQueue Q;
    for (int i = 0; i < GL->vexnum; i++)
    {
        visited[i] = false;
    }
    initQueue(&Q);
    for (int i = 0; i < GL->vexnum; i++)
    {
        if (!visited[i])
        {
            visited[i] = true;
            printf("%c ", GL->adjList[i].data);///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            fdata[fdatanum]=GL->adjList[i].data;
            fdatanum++;
            EnQueue(&Q, i);
            while (!QueueEmpty(Q))
            {
                DeQueue(&Q, &i);
                p = GL->adjList[i].first;
                while (p)
                {
                    if (!visited[p->adjvex])
                    {
                        visited[p->adjvex] = true;
                        printf("%c ", GL->adjList[p->adjvex].data);/////////////////////////////////////////////////////////////////////////////////////////////
                        fdata[fdatanum]=GL->adjList[p->adjvex].data;
                        fdatanum++;
                        EnQueue(&Q, p->adjvex);
                    }
                    p = p->next;
                }
            }
        }
    }
}
///////////////////////////////////////////////// //////////////////////////////////////////////////// //////////////////////////////////////////////////// ///////////////////////////////////////////////// 主函数
int main() {
    printf("*************************************************************************\n");
    printf("****************************  交通工具换乘方案  ****************************\n");
    printf("****************************  数据结构课程设计  ****************************\n");
    printf("****************************  计算机科学与技术  ****************************\n");
    printf("****************************    1834010103   ****************************\n");
    printf("****************************      陈鑫星      ****************************\n");
    printf("****************************   183401010324  ****************************\n");
    printf("****************************  交通工具换乘方案  ****************************\n");
    printf("*************************************************************************\n");
    printf("****************************  已开通的站点如下  ****************************\n");
    printf("a：十三号街      b：开发大道     c：重工街       d：怒江公园      e：铁西广场     \n");
    printf("f：大通湖街      g：浑河站      h：莆田路        i：航空航天大学   j：北市场      \n");
    printf("k：师范大学      l：青年大街     m：市图书馆      n：五里河       o：奥体中心     \n");
    printf("p：全运路        q：新城子      r：自来水厂      s：黎明广场       旅途愉快      \n");
    printf("*************************************************************************\n");
    MGraph G;
    GraphAdjList GL;
    CreateMGraph(&G);
    CreateALGraph(G, &GL);
//    printf("深度优先搜索:\n");
//    DFSTraverse(GL);
//    printf("\n");
//    printf("广度优先搜索:\n");
    BFSTraverse(GL);
//    printf("\n");
//    for(int ii=0;ii<20;++ii)
//    {
//        for(int j=0;j<20;++j)
//        {
//            printf("%d ",test[ii][j]);
//        }
//        printf("\n");
//    }
    
//    for(int i=0;i<20;++i)
//        printf("%c ",fdata[i]);
    int y1,y2;
    for(int i=0;i<20;++i)
    {
        if(fdata[i]==x1){
            y1=i;
//            printf("///y1///%d///",y1);
        }
        else;
        if(fdata[i]==x2){
            y2=i;
//            printf("///y1///%d\n",y2);
        }
        else;
    }
    int zz;
    if(y1<y2)
        ;
    else
    {
        zz=y1;
        y1=y2;
        y2=zz;
    }
    
    //////////////////////////////////////////////////// //////////////////////////////////////////////////// //////////////////////////////////////////////////// 最短路径算法
    
    
    for(int i=y2;i>y1;--i)
    {
        if(fdata[i]=='z')
        continue;
        for(int j=i-1;j>=y1;--j)
        {
            char fuck1=fdata[i];
            char fuck2=fdata[j];
//            printf("\\\\\\\\||%d\n",test[fdata[i]-97][fdata[j]-97]);
            if(  test[fuck1-97][fuck2-97] == 1 )
            {
//                i--;
                break;
            }
            else
            {
                fdata[j]='z';}
        }
    }
    
    
//    printf("\n%d\n",test[1][5]);
//    printf("y1%d   y2%d\n",y1,y2);
    int y3=0;
    char zd[20];
    printf("                              最优路径如下：\n");
//    printf("*************************************************************************\n");
    printf("                          ");
    for(int i=y1;i<=y2;++i)
        if(fdata[i]!='z'){
            printf("%c ",fdata[i]);
            zd[y3]=fdata[i];
            y3++;
        }
    
        int bala[20];
        bala[0]=1;
        bala[1]=1;
        bala[2]=1;
        bala[3]=9;
        bala[4]=10;
        bala[5]=9;
        bala[6]=9;
        bala[7]=2;
        bala[8]=328;
        bala[9]=326;
        bala[10]=328;
        bala[11]=3;
        bala[12]=2;
        bala[13]=2;
        bala[14]=11;
        bala[15]=2;
        bala[16]=326;
        bala[17]=326;
        bala[18]=1;
        bala[19]=9;
    int all[327]={0};
    int fuck3=0;
    int fuck4=0;
    int fuck5=0;
    for(int i=y1;i<=y2;++i)
    {
        if(bala[fdata[i]-97]==11){fuck3=11;
            all[2]++;all[9]++;continue;
        }
        if(bala[fdata[i]-97]==10){fuck4=10;
            all[1]++;all[9]++;continue;
        }
        if(bala[fdata[i]-97]==3){
            all[1]++;all[2]++;continue;
        }
        if(bala[fdata[i]-97]==328){
            all[2]++;all[326]++;continue;
        }
        for(int j=1;j<350;++j)
        {
            if(bala[fdata[i]-97]==j)
            all[j]++;
        }
    }
    fuck5=fuck3+fuck4;
    printf("\n");
//    printf("*************************************************************************\n");
    printf("                                经过站点：\n");
    int jsq=0;
    int fff[10];
    for(int i=1;i<327;++i)
        if(all[i]!=0)
        {
            printf("                                %d  %d  \n",all[i],i);
            if(i==9&&all[i]==2&&fuck5==21)
                all[i]--;
            if(all[i]>1)
            {
                jsq++;
                fff[jsq]=i;
            }
        }
    if(x1!='t'||x1!='p'||x1!='d'||x1!='h'||x1!='j')
        jsq--;
    if(x2=='i'||x2=='o'||x2=='i'||x2=='k')
        jsq--;
    if(jsq<0)
        jsq=0;
    printf("                                转车%d次\n",jsq);////////////////////////////////////////////////////////////////////////////////////////////////////////////                转车算法
        if(jsq!=0)
        {
//            if(bala[fdata[y1]-97]==2)
            if(jsq==3&&bala[fdata[y1]-97]<bala[fdata[y2]-97])
                printf("                    在 e 转 1 号线，在 l 转 2 号线，在 i 转 326 路公交车\n");
            if(jsq==3&&bala[fdata[y1]-97]>bala[fdata[y2]-97])
                printf("                    在 i 转 2 号线，在 l 转 1 号线，在 e 转 9 号线\n");
            if(jsq==1)
            {
                int jsq11;
                int jsq12;
                for(int i=0;i<20;++i)
                {
                    if(bala[i]==fff[1])
                        jsq11=i;
                    if(bala[i]==fff[2])
                        jsq12=i;
                }
                int zhandian=0;
                for(int i=0;i<20;++i)
                {
                    if(bala[i]==bala[jsq11]+bala[jsq12])
                        zhandian=i;
                }
//                jsq11+=jsq12;
                printf("                       在 %c 转 %d \n",zhandian+97,bala[jsq12]);
            }
            if(jsq==2)
            {
                if(bala[x1-97]<bala[x2-97])
                    printf("                    在 l 转 2 号线，在 i 转 326 号公交车\n");
                else
                    printf("                    在 i 转 2 号线，在 l 转 1 号线\n");
            }
        }
        
        //////////////////////////////////////////////////// //////////////////////////////////////////////////// //////////////////////////////////////////////////// 计价算法
    int money1=0;
    int money2=0;
    for(int i=0;i<y3;++i)
    {
        if(zd[i]=='j'||zd[i]=='r'||zd[i]=='q')
            money1=1;
        else
            money2++;
//        printf("\n%c %d %d %d %d\n",zd[i],money2,money1,y1,y2);
    }
//    printf("\n");
    if(money2==1)
        money2=0;
    if(money2==2 && (x1=='j'||x1=='k'||x2=='j'||x2=='k')  )
        money2=0;
    if(money2>7)
        money2=5;
    else if(money2>1&&money2<8)
        money2=3;
    if(money1==0)
        money1=money2;
    else
    {
        money1+=money2;
        money2=money1+1;
    }
    if(money1==money2)
        printf("                              本次费用为: %d元\n",money1);
    else
        printf("                                本次费用为:\n                              乘坐普通公交：%d元\n                              乘坐空调公交：%d元\n",money1,money2);
    
    int time;
    time=y2-y1;
    time*=7;
    printf("                            大约路途时间为: %d分钟\n",time);
    
        
//        ***
        //最短路径算法
        //转车算法
        //计价算法
//        ***
    
    
//    char fuck='a';
//    printf("%d",fuck-97);
//    return 0;
    /*
    MGraph G;
    CreateMGraph(&G);
    DFSTraverse(G);
    printf("\n");
    BFSTraverse(G);
    return 0;
    */
}

